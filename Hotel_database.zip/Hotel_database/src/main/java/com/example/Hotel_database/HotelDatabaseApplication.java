package com.example.Hotel_database;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelDatabaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelDatabaseApplication.class, args);
	}

}
